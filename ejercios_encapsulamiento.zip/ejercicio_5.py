class SeleOp:
    def __init__(self):
        self.__opciones_validas = ["inicio", "configuracion", "ayuda", "salir"]
        self.__opcion_actual = "inicio"  
        
    @property
    def opcion(self) -> str:
        return self.__opcion_actual

    @opcion.setter
    def opcion(self, nueva_opcion: str):
        if nueva_opcion.lower() in self.__opciones_validas:
            self.__opcion_actual = nueva_opcion.lower()
        else:
            print(f"Error: Opción no válida. Use: {', '.join(self.__opciones_validas)}")

    def ejecutar(self):
        acciones = {
            "inicio": " Cargando pantalla de inicio...",
            "configuracion": " Abriendo configuración...",
            "ayuda": " Mostrando ayuda...",
            "salir": " Cerrando la aplicación..."
        }
        print(acciones.get(self.__opcion_actual, "⚠️ Opción no implementada"))

if __name__ == "__main__":
    selector = SeleOp()
    
    selector.opcion = "ayuda"
    selector.ejecutar() 
    
    selector.opcion = "admin"
    selector.ejecutar()  
    
    print(f"Opción actual: {selector.opcion}") 