class Cuenta:
    def __init__(self, usuario: str, contraseña: str):
        self.__usuario = usuario  
        self.__contraseña = self.__encriptar(contraseña)  
        self.__bloqueada = False  
    
    def iniciar_sesion(self, usuario_intento: str, contraseña_intento: str) -> bool:
        if self.__bloqueada:
            print("Cuenta bloqueada. Contacta al soporte.")
            return False
        
        if usuario_intento == self.__usuario and self.__encriptar(contraseña_intento) == self.__contraseña:
            print("Bienvenido!")
            return True
        else:
            print("Usuario o contraseña incorrectos")
            return False
    
    def cambiar_contraseña(self, vieja_contraseña: str, nueva_contraseña: str) -> bool:
        if self.__encriptar(vieja_contraseña) == self.__contraseña:
            self.__contraseña = self.__encriptar(nueva_contraseña)
            print("Contraseña actualizada")
            return True
        print("Contraseña actual incorrecta")
        return False
    
    def __encriptar(self, texto: str) -> str:
        return str(len(texto)) + texto[::-1]  

if __name__ == "__main__":
    mi_cuenta = Cuenta("admin", "secreto123")
    
    mi_cuenta.iniciar_sesion("admin", "malacontraseña")  
    mi_cuenta.iniciar_sesion("admin", "secreto123")      
    
    mi_cuenta.cambiar_contraseña("secreto123", "nuevacontraseña")
    mi_cuenta.iniciar_sesion("admin", "nuevacontraseña") 