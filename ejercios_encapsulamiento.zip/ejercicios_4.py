class Factura:
    def __init__(self):
        self.__productos = [] 
        self.__iva = 0.19      
    
    def agregar_producto(self, nombre: str, precio: float):
        if precio <= 0:
            raise ValueError("El precio debe ser positivo")
        self.__productos.append((nombre, precio))
    
    def __calcular_subtotal(self) -> float:
        return sum(precio for _, precio in self.__productos)
    
    def calcular_total(self) -> float:
        subtotal = self.__calcular_subtotal()
        return subtotal * (1 + self.__iva)
    
    def mostrar_factura(self):
        print("\n=== FACTURA ===")
        for nombre, precio in self.__productos:
            print(f"- {nombre}: ${precio:.2f}")
        print("---------------")
        print(f"Subtotal: ${self.__calcular_subtotal():.2f}")
        print(f"IVA ({self.__iva*100}%): ${self.__calcular_subtotal() * self.__iva:.2f}")
        print(f"TOTAL: ${self.calcular_total():.2f}")
        print("===============")

if __name__ == "__main__":
    mi_factura = Factura()
    
    mi_factura.agregar_producto("Camisa", 25.99)
    mi_factura.agregar_producto("Pantalón", 35.50)
    mi_factura.agregar_producto("Zapatos", 49.99)
    
    mi_factura.mostrar_factura()