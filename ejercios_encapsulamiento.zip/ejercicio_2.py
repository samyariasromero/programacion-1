class Pago:
    def __init__(self, monto):
        self.__monto = monto         
        self.__estado = "Pendiente"   
        self.__tarjeta = None         

    def pagar(self, tarjeta, cvv):
        if len(tarjeta) == 16 and tarjeta.isdigit() and len(cvv) == 3:
            self.__tarjeta = "****-****-****-" + tarjeta[-4:]  
            self.__estado = "Aprobado" 
            return True
        else:
            self.__estado = "Rechazado"
            return False

    def ver_pago(self):
        print(f"Monto: ${self.__monto}")
        print(f"Estado: {self.__estado}")
        if self.__tarjeta:
            print(f"Tarjeta: {self.__tarjeta}")

if __name__ == "__main__":
    pago1 = Pago(100.50)
    
    if pago1.pagar("977777777777", "123"):
        print("¡Pago exitoso!")
    else:
        print("Pago fallido")
    
    pago1.ver_pago()