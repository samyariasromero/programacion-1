class Estudiante:
    def __init__(self, nombre: str, edad: int):
        self.__nombre = nombre  
        self.__edad = edad      
        self.__notas = []      

    @property
    def nombre(self) -> str:
        return self.__nombre
    
    @property
    def edad(self) -> int:
        return self.__edad
    
    @property
    def notas(self) -> list:
        return self.__notas.copy() 
    
    def agregar_nota(self, nota: float):
        if 0.0 <= nota <= 5.0:
            self.__notas.append(nota)
        else:
            raise ValueError("La nota debe estar entre 0.0 y 5.0")
    
    def eliminar_nota(self, indice: int):
        if 0 <= indice < len(self.__notas):
            return self.__notas.pop(indice)
        raise IndexError("Índice de nota no válido")
    
    def promedio(self) -> float:
        if not self.__notas:
            return 0.0
        return sum(self.__notas) / len(self.__notas)
    
    def __str__(self) -> str:
        return (f"Estudiante: {self.__nombre}\n"
                f"Edad: {self.__edad}\n"
                f"Notas: {self.__notas}\n"
                f"Promedio: {self.promedio():.2f}")

if __name__ == "__main__":
    estuejem = Estudiante("Laura Méndez", 21)
    estuejem.agregar_nota(4.7)
    estuejem.agregar_nota(3.9)
    
    print(estuejem)